package com.simulator.moto6809.UI;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

final class Row {
    private final int address;
    private final StringProperty addr = new SimpleStringProperty();
    private final StringProperty hex = new SimpleStringProperty();

    Row(int address, String addrText, String hexText) {
        this.address = address & 0xFFFF;
        this.addr.set(addrText);
        this.hex.set(hexText);
    }

    int address() { return address; }

    StringProperty addrProperty() { return addr; }
    StringProperty hexProperty() { return hex; }

    void setHex(String s) { hex.set(s); }
}
