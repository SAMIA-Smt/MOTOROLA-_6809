package com.simulator.moto6809.Logger;

    public enum LogLevel
    {
        DEBUG,
        INFO,
        WARNING,
        ERROR
    }

