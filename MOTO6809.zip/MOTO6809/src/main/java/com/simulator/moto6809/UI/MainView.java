package com.simulator.moto6809.UI;
import javafx.scene.layout.FlowPane;
import javafx.animation.AnimationTimer;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;

import java.util.Collections;

public final class MainView {

    private final CentralController controller = new CentralController();
    public CentralController controller() { return controller; }

    private final BorderPane root = new BorderPane();

    private final CodeArea codeArea = new CodeArea();

    private Integer highlightedLine = null;

    private final TextField originField = new TextField("$E000");
    private final TextField maxField = new TextField("200000");

    private final ListView<String> console = new ListView<>();

    private java.util.function.IntFunction<javafx.scene.Node> gutterFactory;

    private AnimationTimer timer;

    public MainView() {
        buildLayout();
        wireActions();
        setupEditorGutterWithBreakpoints();
        setupConsole();
        setupRegistersPanel();
        setupCenterTabs();
    }

    public Parent getRoot() { return root; }

    private void buildLayout() {
        root.setPadding(new Insets(8));

        ToolBar toolBar = new ToolBar();
        Button btnAssemble = new Button("Assemble / Load");
        Button btnRun = new Button("Run");
        Button btnPause = new Button("Pause");
        Button btnStep = new Button("Step");
        Button btnResetCpu = new Button("Reset CPU");
        Button btnClearRam = new Button("Clear RAM");
        //Button btnClearRom = new Button("Clear ROM");
        Button btnClearConsole = new Button("Clear Console");

        originField.setPrefColumnCount(8);
        maxField.setPrefColumnCount(8);

        toolBar.getItems().addAll(
                btnAssemble,
                new Separator(),
                btnRun, btnPause, btnStep, btnResetCpu,
                new Separator(),
                new Label("Origin:"), originField,
                new Label("Max:"), maxField,
                new Separator(),
                btnClearRam, //btnClearRom,
                new Separator(),
                btnClearConsole
        );
        root.setTop(toolBar);

        // Editor (left)
        codeArea.setPrefWidth(520);
        codeArea.setParagraphGraphicFactory(LineNumberFactory.get(codeArea));
        codeArea.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 13px;");
        codeArea.replaceText(defaultProgram());

        root.setLeft(new VirtualizedScrollPane<>(codeArea));

        // Center tabs
        TabPane centerTabs = new TabPane();
        centerTabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        root.setCenter(centerTabs);

        // Right registers
        VBox right = new VBox(10);
        right.setPadding(new Insets(8));
        right.setPrefWidth(320);
        right.setStyle("-fx-background-color: #0f172a10; -fx-background-radius: 10;");
        root.setRight(right);

        // Console bottom
        console.setPrefHeight(220);
        root.setBottom(console);

        // Store
        root.getProperties().put("btnAssemble", btnAssemble);
        root.getProperties().put("btnRun", btnRun);
        root.getProperties().put("btnPause", btnPause);
        root.getProperties().put("btnStep", btnStep);
        root.getProperties().put("btnResetCpu", btnResetCpu);
        root.getProperties().put("btnClearRam", btnClearRam);
        //root.getProperties().put("btnClearRom", btnClearRom);
        root.getProperties().put("btnClearConsole", btnClearConsole);
        root.getProperties().put("centerTabs", centerTabs);
    }

    private void wireActions() {
        Button btnAssemble = (Button) root.getProperties().get("btnAssemble");
        Button btnRun = (Button) root.getProperties().get("btnRun");
        Button btnPause = (Button) root.getProperties().get("btnPause");
        Button btnStep = (Button) root.getProperties().get("btnStep");
        Button btnResetCpu = (Button) root.getProperties().get("btnResetCpu");
        Button btnClearRam = (Button) root.getProperties().get("btnClearRam");
        //Button btnClearRom = (Button) root.getProperties().get("btnClearRom");
        Button btnClearConsole = (Button) root.getProperties().get("btnClearConsole");

        // Disable run/step/reset/clear while not loaded OR busy
        btnRun.disableProperty().bind(controller.programLoadedProperty().not().or(controller.busyProperty()));
        btnStep.disableProperty().bind(controller.programLoadedProperty().not().or(controller.busyProperty()));
        btnResetCpu.disableProperty().bind(controller.busyProperty());
        btnClearRam.disableProperty().bind(controller.busyProperty());
        //btnClearRom.disableProperty().bind(controller.busyProperty());

        btnAssemble.disableProperty().bind(controller.busyProperty());

        btnAssemble.setOnAction(e -> {
            Integer origin = parseHexOrNull(originField.getText());
            controller.assembleAndLoad(codeArea.getText(), origin);
        });

        btnRun.setOnAction(e -> controller.run(parseIntSafe(maxField.getText(), 200000)));
        btnPause.setOnAction(e -> controller.pause());
        btnStep.setOnAction(e -> controller.step());
        btnResetCpu.setOnAction(e -> controller.resetCpu());

        btnClearRam.setOnAction(e -> controller.clearRam());
        //btnClearRom.setOnAction(e -> controller.clearRom());
        btnClearConsole.setOnAction(e -> controller.consoleLines().clear());
    }

    private void setupCenterTabs() {
        TabPane centerTabs = (TabPane) root.getProperties().get("centerTabs");

        MemoryGridPane ramPane = new MemoryGridPane(
                "RAM",
                addr -> controller.peekByte(addr),
                (a, v) -> controller.pokeByte(a, v),   //  editable
                controller.ramStart(),
                controller.ramEnd()
        );

        MemoryGridPane romPane = new MemoryGridPane(
                "ROM",
                addr -> controller.peekByte(addr),
                null,                                  //  read-only
                controller.romStart(),
                controller.romEnd()
        );

        /*MemoryPane ramPane = new MemoryPane(
                "RAM",
                addr -> controller.peekByte(addr),
                (a, v) -> { controller.pokeByte(a, v); return 0; }, //  editable
                controller.ramStart(),
                controller.ramEnd(),
                0x400
        );

        MemoryPane romPane = new MemoryPane(
                "ROM",
                addr -> controller.peekByte(addr),
                null, //  read-only
                controller.romStart(),
                controller.romEnd(),
                0x400
        );*/

        /*33MemoryPane ramPane = new MemoryPane(
                "RAM",
                addr -> controller.peekByte(addr),
                controller.ramStart(),
                controller.ramEnd(),
                0x400  // page size (change if you want)
        );

        MemoryPane romPane = new MemoryPane(
                "ROM",
                addr -> controller.peekByte(addr),
                controller.romStart(),
                controller.romEnd(),
                0x400
        );*/

        ProgramPane progPane = new ProgramPane(controller.programRows());
        Tab program = new Tab("Program", progPane);
        Tab ram = new Tab("RAM", ramPane);
        Tab rom = new Tab("ROM", romPane);

        centerTabs.getTabs().setAll(ram, rom, program);

        root.getProperties().put("ramPane", ramPane);
        root.getProperties().put("romPane", romPane);
        root.getProperties().put("programPane", progPane);

    }

    private void setupRegistersPanel() {
        VBox right = (VBox) root.getRight();
        right.getChildren().clear();

        Label title = new Label("CPU State");
        title.setFont(Font.font(16));

        Label pc = new Label();
        pc.textProperty().bind(Bindings.createStringBinding(
                () -> "PC: " + hex16(controller.pcProperty().get()),
                controller.pcProperty()
        ));

        Label cycles = new Label();
        cycles.textProperty().bind(Bindings.createStringBinding(
                () -> "Cycles: " + controller.cyclesProperty().get(),
                controller.cyclesProperty()
        ));

        Label last = new Label();
        last.setWrapText(true);
        last.textProperty().bind(controller.lastInstructionProperty());

        FlowPane cards = new FlowPane();
        cards.setHgap(10);
        cards.setVgap(10);
        cards.setPrefWrapLength(280); // wrap in right panel

        cards.getChildren().add(regCard("A", 8, controller.regA, com.simulator.moto6809.Registers.Register.A));
        cards.getChildren().add(regCard("B", 8, controller.regB, com.simulator.moto6809.Registers.Register.B));
        cards.getChildren().add(regCard("D", 16, controller.regD, com.simulator.moto6809.Registers.Register.D));
        cards.getChildren().add(regCard("X", 16, controller.regX, com.simulator.moto6809.Registers.Register.X));
        cards.getChildren().add(regCard("Y", 16, controller.regY, com.simulator.moto6809.Registers.Register.Y));
        cards.getChildren().add(regCard("S", 16, controller.regS, com.simulator.moto6809.Registers.Register.S));
        cards.getChildren().add(regCard("U", 16, controller.regU, com.simulator.moto6809.Registers.Register.U));
        cards.getChildren().add(regCard("DP", 8, controller.regDP, com.simulator.moto6809.Registers.Register.DP));
        cards.getChildren().add(regCard("CC", 8, controller.regCC, com.simulator.moto6809.Registers.Register.CC));

        /*33GridPane regs = new GridPane();
        regs.setHgap(8); regs.setVgap(6);

        int r = 0;
        addReg(regs, r++, "A", controller.regA, 8);
        addReg(regs, r++, "B", controller.regB, 8);
        addReg(regs, r++, "D", controller.regD, 16);
        addReg(regs, r++, "X", controller.regX, 16);
        addReg(regs, r++, "Y", controller.regY, 16);
        addReg(regs, r++, "S", controller.regS, 16);
        addReg(regs, r++, "U", controller.regU, 16);
        addReg(regs, r++, "DP", controller.regDP, 8);
        addReg(regs, r++, "CC", controller.regCC, 8);*/

        GridPane flags = new GridPane();
        flags.setHgap(8); flags.setVgap(6);
        int fr = 0;
        flags.add(new Label("Flags:"), 0, fr++, 2, 1);
        flags.add(flagChip("E", controller.fE), 0, fr);
        flags.add(flagChip("F", controller.fF), 1, fr++);

        flags.add(flagChip("H", controller.fH), 0, fr);
        flags.add(flagChip("I", controller.fI), 1, fr++);

        flags.add(flagChip("N", controller.fN), 0, fr);
        flags.add(flagChip("Z", controller.fZ), 1, fr++);

        flags.add(flagChip("V", controller.fV), 0, fr);
        flags.add(flagChip("C", controller.fC), 1, fr++);

        right.getChildren().addAll(
                title, pc, cycles,
                new Separator(),
                cards,//33resgs
                new Separator(),
                flags,
                new Separator(),
                new Label("Last instruction:"),
                last
        );
    }

    private void setupConsole() {
        console.setItems(controller.consoleLines());
        console.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 12px;");
    }

    // Breakpoints gutter
    private void setupEditorGutterWithBreakpoints() {

        final var lineNumberFactory = LineNumberFactory.get(codeArea);

        gutterFactory = lineIndex -> {
            var ln = lineNumberFactory.apply(lineIndex);

            // ✅ REAL circle: cannot become oval
            javafx.scene.shape.Circle dot = new javafx.scene.shape.Circle(6);

            boolean enabled = controller.breakpointLines().contains(lineIndex);

            if (enabled) {
                dot.setFill(javafx.scene.paint.Color.web("#ef4444"));
                dot.setStroke(javafx.scene.paint.Color.web("#ef4444"));
                dot.setEffect(new javafx.scene.effect.DropShadow(
                        10,
                        javafx.scene.paint.Color.rgb(239, 68, 68, 0.8)
                ));
            } else {
                dot.setFill(javafx.scene.paint.Color.TRANSPARENT);
                dot.setStroke(javafx.scene.paint.Color.web("#94a3b8"));
            }

            // Wrap to keep a fixed click area
            StackPane dotWrap = new StackPane(dot);
            dotWrap.setMinSize(16, 16);
            dotWrap.setPrefSize(16, 16);
            dotWrap.setMaxSize(16, 16);

            dotWrap.setOnMouseClicked(ev -> {
                if (ev.getButton() == MouseButton.PRIMARY) {
                    controller.toggleBreakpointLine(lineIndex);
                    applyLineStyle(lineIndex);   // ✅ highlight this line
                    refreshGutter();
                    ev.consume();
                }
            });

            HBox box = new HBox(6, dotWrap, ln);
            box.setAlignment(Pos.CENTER_LEFT);
            box.setPadding(new Insets(0, 6, 0, 6));
            return box;
        };

        codeArea.setParagraphGraphicFactory(gutterFactory);

        controller.breakpointLines().addListener(
                (javafx.collections.SetChangeListener<Integer>) change -> {
                    Integer line = change.wasAdded() ? change.getElementAdded() : change.getElementRemoved();
                    if (line != null) applyLineStyle(line);
                    refreshGutter();
                }
        );
    }

    private void refreshGutter() {
        if (gutterFactory == null) return;
        codeArea.setParagraphGraphicFactory(i -> null);
        codeArea.setParagraphGraphicFactory(gutterFactory);
    }

    private void highlightLine(Integer lineIndex) {

        // re-apply style on old highlighted line (keep breakpoint style if any)
        if (highlightedLine != null) {
            int old = highlightedLine;
            highlightedLine = null;
            applyLineStyle(old);
        }

        highlightedLine = lineIndex;

        if (lineIndex == null || lineIndex < 0) return;

        int lineCount = codeArea.getText().split("\\R", -1).length;
        if (lineIndex >= lineCount) return;

        applyLineStyle(lineIndex);  //  applies pc-line (+ bp-line if exists)
        codeArea.showParagraphAtTop(Math.max(0, lineIndex - 3));
    }


    /*private void highlightLine(Integer lineIndex) {
        if (highlightedLine != null) {
            try { codeArea.setParagraphStyle(highlightedLine, Collections.emptyList()); }
            catch (Exception ignored) {}
        }
        highlightedLine = lineIndex;
        if (lineIndex == null || lineIndex < 0) return;
        int lineCount = codeArea.getText().split("\\R", -1).length;
        if (lineIndex >= lineCount) return;

        codeArea.setParagraphStyle(lineIndex, Collections.singletonList("pc-line"));
        codeArea.showParagraphAtTop(Math.max(0, lineIndex - 3));
    }*/

    public void startUiPump() {
        timer = new AnimationTimer() {
            private long last = 0;
            @Override public void handle(long now) {
                if (last != 0 && (now - last) < 16_000_000) return;
                last = now;

                controller.pumpUi();

                MemoryGridPane ramPane = (MemoryGridPane) root.getProperties().get("ramPane");
                MemoryGridPane romPane = (MemoryGridPane) root.getProperties().get("romPane");
                if (ramPane != null) ramPane.refresh();
                if (romPane != null) romPane.refresh();

                /*MemoryPane ramPane = (MemoryPane) root.getProperties().get("ramPane");
                MemoryPane romPane = (MemoryPane) root.getProperties().get("romPane");
                if (ramPane != null) ramPane.refresh();
                if (romPane != null) romPane.refresh();*/

                Integer line = controller.lineForPc(controller.pcProperty().get());
                if (line != null && !line.equals(highlightedLine)) highlightLine(line);
            }
        };
        timer.start();
    }

    // Helpers
// BREAKPOINT HELPERS FOR LINE SHADOW
    private void applyLineStyle(int lineIndex) {
        if (lineIndex < 0) return;

        java.util.List<String> styles = new java.util.ArrayList<>();

        // breakpoint highlight
        if (controller.breakpointLines().contains(lineIndex)) styles.add("bp-line");

        // pc highlight
        if (highlightedLine != null && highlightedLine.equals(lineIndex)) styles.add("pc-line");

        codeArea.setParagraphStyle(lineIndex, styles);
    }



    //registres

    private Pane regCard(String name,
                         int bits,
                         javafx.beans.property.IntegerProperty valueProp,
                         com.simulator.moto6809.Registers.Register reg) {

        final int digits = (bits == 8) ? 2 : 4;
        final int mask   = (bits == 8) ? 0xFF : 0xFFFF;

        Label lbl = new Label(name);
        lbl.setStyle("-fx-font-weight: bold; -fx-font-size: 13px;");

        TextField field = new TextField();
        field.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 13px;");
        field.setPrefColumnCount(digits + 1);

        // display initial "$00" or "$0000"
        field.setText(formatDollarHex(valueProp.get(), digits));

        // ✅ allow only "$" + up to N hex digits, never block typing
        installDollarHexFormatter(field, digits);

        // update from CPU only when not editing
        valueProp.addListener((obs, oldV, newV) -> {
            if (!field.isFocused()) {
                field.setText(formatDollarHex(newV.intValue() & mask, digits));
            }
        });

        // ✅ click/focus: keep "$", remove zeros after it
        field.focusedProperty().addListener((o, was, is) -> {
            if (is) {
                prepareEdit(field); // "$0000" -> "$"
                // select everything after "$"
                field.selectRange(1, field.getText().length());
            } else {
                commitRegister(field, valueProp, reg, digits, mask);
            }
        });

        // Enter commits too
        field.setOnAction(e -> commitRegister(field, valueProp, reg, digits, mask));

        VBox box = new VBox(6, lbl, field);
        box.setStyle("""
            -fx-background-color: white;
            -fx-border-color: #cbd5e1;
            -fx-border-radius: 10;
            -fx-background-radius: 10;
            -fx-padding: 10;
            -fx-min-width: 90;
            """);

        return box;
    }
   // end registers helper
    private void addReg(GridPane grid, int row, String name, javafx.beans.property.IntegerProperty value, int bits) {
        Label k = new Label(name + ":");
        Label v = new Label();
        v.setStyle("-fx-font-family: 'Consolas';");
        v.textProperty().bind(Bindings.createStringBinding(
                () -> (bits == 8 ? hex8(value.get()) : hex16(value.get())),
                value
        ));
        grid.add(k, 0, row);
        grid.add(v, 1, row);
    }

    private HBox flagChip(String name, javafx.beans.property.BooleanProperty on) {
        Label l = new Label(name);
        l.setMinWidth(18);
        l.setAlignment(Pos.CENTER);

        Region dot = new Region();
        dot.setMinSize(10, 10);
        dot.setPrefSize(10, 10);

        dot.styleProperty().bind(Bindings.createStringBinding(() -> {
            if (on.get()) return "-fx-background-color: #22c55e; -fx-background-radius: 5;";
            return "-fx-background-color: #94a3b8; -fx-background-radius: 5;";
        }, on));

        HBox box = new HBox(6, dot, l);
        box.setAlignment(Pos.CENTER_LEFT);
        return box;
    }

    private static Integer parseHexOrNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        t = t.replace("_", "");
        if (t.startsWith("$")) t = t.substring(1);
        if (t.startsWith("0x") || t.startsWith("0X")) t = t.substring(2);
        return Integer.parseInt(t, 16) & 0xFFFF;
    }

    private static int parseIntSafe(String s, int def) {
        try { return Integer.parseInt(s.trim()); }
        catch (Exception e) { return def; }
    }

    private static String hex8(int v) { return String.format("$%02X", v & 0xFF); }
    private static String hex16(int v) { return String.format("$%04X", v & 0xFFFF); }

    private static String defaultProgram() {
        return """
                ORG $E000
                START:
                    LDA #$42
                    STA $0100
                    BRA START
                END
                """;
    }

    // REGISTER HELPERS
    private static String formatDollarHex(int v, int digits) {
        int mask = (digits == 2) ? 0xFF : 0xFFFF;
        return "$" + String.format("%0" + digits + "X", v & mask);
    }

    private static void prepareEdit(TextField field) {
        String t = field.getText() == null ? "" : field.getText().trim().toUpperCase();
        if (!t.startsWith("$")) t = "$" + t;

        String raw = t.substring(1);     // part after $
        raw = raw.replaceFirst("^0+", ""); // remove ALL leading zeros
        if (raw.isEmpty()) {
            field.setText("$");           // keep only $
        } else {
            field.setText("$" + raw);
        }
    }

    private void commitRegister(TextField field,
                                javafx.beans.property.IntegerProperty valueProp,
                                com.simulator.moto6809.Registers.Register reg,
                                int digits,
                                int mask) {

        String t = field.getText() == null ? "" : field.getText().trim().toUpperCase();
        if (!t.startsWith("$")) t = "$" + t;

        String raw = t.substring(1).trim();   // digits only

        // ✅ if user left it empty ("$") -> revert to current register value
        if (raw.isEmpty()) {
            field.setText(formatDollarHex(valueProp.get(), digits));
            return;
        }

        // validate
        if (!raw.matches("[0-9A-F]{1," + digits + "}")) {
            field.setText(formatDollarHex(valueProp.get(), digits));
            return;
        }

        int v = Integer.parseInt(raw, 16) & mask;

        controller.setRegister(reg, v);

        // display padded with zeros again
        field.setText(formatDollarHex(v, digits));
    }

    private static void installDollarHexFormatter(TextField field, int digits) {
        field.setTextFormatter(new TextFormatter<String>(change -> {

            // Uppercase what user inserts
            if (change.getText() != null) {
                change.setText(change.getText().toUpperCase());
            }

            String newText = change.getControlNewText();
            if (newText == null) return change;

            newText = newText.toUpperCase();

            // Always keep at least "$"
            if (newText.isEmpty()) {
                change.setRange(0, change.getControlText().length());
                change.setText("$");
                return change;
            }

            // If user types without "$" (ex: selects all and types "AB"), we auto-add "$"
            if (!newText.startsWith("$")) {
                String raw = newText.replaceAll("[^0-9A-F]", "");
                if (raw.length() > digits) raw = raw.substring(0, digits);

                change.setRange(0, change.getControlText().length());
                change.setText("$" + raw);
                return change;
            }

            // After "$": only hex and max N digits
            String raw = newText.substring(1);

            if (raw.length() > digits) return null;
            if (!raw.matches("[0-9A-F]*")) return null;

            return change;
        }));

        // Optional safety: prevent caret before "$"
        field.caretPositionProperty().addListener((obs, oldV, newV) -> {
            if (field.isFocused() && newV.intValue() < 1) {
                field.positionCaret(1);
            }
        });
    }

}

/*11package com.simulator.moto6809.UI;

import javafx.animation.AnimationTimer;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;

import java.util.Collections;

public final class MainView {

    private final CentralController controller = new CentralController();

    private java.util.function.IntFunction<Node> gutterFactory;
    private final BorderPane root = new BorderPane();

    // Editor
    private final CodeArea codeArea = new CodeArea();
    private Integer highlightedLine = null;

    // Toolbar fields
    private final TextField originField = new TextField("$E000");
    private final TextField maxField = new TextField("100000");

    // Console
    private final ListView<String> console = new ListView<>();

    // UI pump
    private AnimationTimer timer;

    public MainView() {
        buildLayout();
        setupConsole();
        setupEditorGutterWithBreakpoints();
        setupRegistersPanel();
        setupCenterTabsPlaceholders();
        wireActions();
    }

    public Parent getRoot() {
        return root;
    }


    // Layout

    private void buildLayout() {
        root.setPadding(new Insets(8));

        ToolBar toolBar = new ToolBar();
        Button btnAssemble = new Button("Assemble / Load");
        Button btnRun = new Button("Run");
        Button btnPause = new Button("Pause");
        Button btnStep = new Button("Step");
        Button btnReset = new Button("Reset");
        Button btnClearConsole = new Button("Clear Console");

        originField.setPrefColumnCount(8);
        maxField.setPrefColumnCount(8);

        toolBar.getItems().addAll(
                btnAssemble,
                new Separator(),
                btnRun, btnPause, btnStep, btnReset,
                new Separator(),
                new Label("Origin:"), originField,
                new Label("Max:"), maxField,
                new Separator(),
                btnClearConsole
        );

        root.setTop(toolBar);

        // Left editor
        codeArea.setPrefWidth(520);
        codeArea.setParagraphGraphicFactory(LineNumberFactory.get(codeArea));
        codeArea.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 13px;");
        codeArea.replaceText(defaultProgram());

        VirtualizedScrollPane<CodeArea> editorPane = new VirtualizedScrollPane<>(codeArea);
        editorPane.setPrefWidth(520);
        root.setLeft(editorPane);

        // Center tabs
        TabPane centerTabs = new TabPane();
        centerTabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        root.setCenter(centerTabs);

        // Right panel container
        VBox right = new VBox(10);
        right.setPadding(new Insets(8));
        right.setPrefWidth(320);
        right.setStyle("-fx-background-color: #0f172a10; -fx-background-radius: 10;");
        root.setRight(right);

        // Bottom console
        console.setPrefHeight(220);
        root.setBottom(console);

        // Store references
        root.getProperties().put("btnAssemble", btnAssemble);
        root.getProperties().put("btnRun", btnRun);
        root.getProperties().put("btnPause", btnPause);
        root.getProperties().put("btnStep", btnStep);
        root.getProperties().put("btnReset", btnReset);
        root.getProperties().put("btnClearConsole", btnClearConsole);
        root.getProperties().put("centerTabs", centerTabs);
    }

    private void wireActions() {
        Button btnAssemble = (Button) root.getProperties().get("btnAssemble");
        Button btnRun = (Button) root.getProperties().get("btnRun");
        Button btnPause = (Button) root.getProperties().get("btnPause");
        Button btnStep = (Button) root.getProperties().get("btnStep");
        Button btnReset = (Button) root.getProperties().get("btnReset");
        Button btnClearConsole = (Button) root.getProperties().get("btnClearConsole");

        // Disable Run/Step/Reset until program loaded
        btnRun.disableProperty().bind(controller.programLoadedProperty().not());
        btnStep.disableProperty().bind(controller.programLoadedProperty().not());
        btnReset.disableProperty().bind(controller.programLoadedProperty().not());

        btnAssemble.setOnAction(e -> {
            try {
                Integer origin = parseHexOrNull(originField.getText());
                controller.assembleAndLoad(codeArea.getText(), origin);
            } catch (Exception ex) {
                controller.consoleLines().add("[ERROR] Assemble failed: " + ex.getMessage());
            }
        });

        btnRun.setOnAction(e -> {
            try {
                int max = parseIntSafe(maxField.getText(), 100000);
                controller.run(max);
            } catch (Exception ex) {
                controller.consoleLines().add("[ERROR] Run failed: " + ex.getMessage());
            }
        });

        btnPause.setOnAction(e -> controller.pause());
        btnStep.setOnAction(e -> controller.step());
        btnReset.setOnAction(e -> controller.reset());

        btnClearConsole.setOnAction(e -> controller.consoleLines().clear());
    }


    // Editor gutter: breakpoints + highlight

    private void setupEditorGutterWithBreakpoints() {
        final var lineNumberFactory = LineNumberFactory.get(codeArea);

        gutterFactory = lineIndex -> {
            var ln = lineNumberFactory.apply(lineIndex);

            StackPane dot = new StackPane();
            dot.setMinSize(12, 12);
            dot.setPrefSize(12, 12);
            dot.setMaxSize(12, 12);

            boolean enabled = controller.breakpointLines().contains(lineIndex);
            dot.setStyle(enabled
                    ? "-fx-background-color: #ef4444; -fx-background-radius: 6;"
                    : "-fx-background-color: transparent; -fx-border-color: #94a3b8; -fx-border-radius: 6;");

            dot.setOnMouseClicked(ev -> {
                if (ev.getButton() == MouseButton.PRIMARY) {
                    controller.toggleBreakpointLine(lineIndex);
                    refreshGutter();
                    ev.consume();
                }
            });

            HBox box = new HBox(6, dot, ln);
            box.setAlignment(Pos.CENTER_LEFT);
            box.setPadding(new Insets(0, 6, 0, 6));
            return box;
        };

        codeArea.setParagraphGraphicFactory(gutterFactory);

        controller.breakpointLines().addListener(
                (javafx.collections.SetChangeListener<Integer>) change -> refreshGutter()
        );
    }

    private void refreshGutter() {
        if (gutterFactory == null) return;
        codeArea.setParagraphGraphicFactory(i -> null);
        codeArea.setParagraphGraphicFactory(gutterFactory);
    }

    private void highlightLine(Integer lineIndex) {
        if (highlightedLine != null) {
            try { codeArea.setParagraphStyle(highlightedLine, Collections.emptyList()); }
            catch (Exception ignored) {}
        }

        highlightedLine = lineIndex;
        if (lineIndex == null || lineIndex < 0) return;

        int lineCount = codeArea.getText().split("\\R", -1).length;
        if (lineIndex >= lineCount) return;

        // Simple highlight (needs CSS class support in RichTextFX)
        codeArea.setParagraphStyle(lineIndex, Collections.singletonList("pc-line"));
        codeArea.showParagraphAtTop(Math.max(0, lineIndex - 3));
    }


    // Center tabs placeholders

    private void setupCenterTabsPlaceholders() {
        TabPane centerTabs = (TabPane) root.getProperties().get("centerTabs");

        MemoryPane ramPane = new MemoryPane("RAM", controller::peekByte, 0x0000, 256);
        MemoryPane romPane = new MemoryPane("ROM", controller::peekByte, 0xE000, 256);

        Tab ram = new Tab("RAM"); ram.setContent(ramPane);
        Tab rom = new Tab("ROM"); rom.setContent(romPane);
        Tab program = new Tab("Programme"); program.setContent(new Label("Programme window — prochaine étape."));

        centerTabs.getTabs().setAll(ram, rom, program);

        root.getProperties().put("ramPane", ramPane);
        root.getProperties().put("romPane", romPane);
    }


    // Right panel: registers + flags

    private void setupRegistersPanel() {
        VBox right = (VBox) root.getRight();
        right.getChildren().clear();

        Label title = new Label("CPU State");
        title.setFont(Font.font(16));

        Label pc = new Label();
        pc.textProperty().bind(Bindings.createStringBinding(
                () -> "PC: " + hex16(controller.pcProperty().get()),
                controller.pcProperty()
        ));

        Label cycles = new Label();
        cycles.textProperty().bind(Bindings.createStringBinding(
                () -> "Cycles: " + controller.cyclesProperty().get(),
                controller.cyclesProperty()
        ));

        Label last = new Label();
        last.setWrapText(true);
        last.textProperty().bind(controller.lastInstructionProperty());

        GridPane regs = new GridPane();
        regs.setHgap(8);
        regs.setVgap(6);

        int r = 0;
        addReg(regs, r++, "A", controller.regA, 8);
        addReg(regs, r++, "B", controller.regB, 8);
        addReg(regs, r++, "D", controller.regD, 16);
        addReg(regs, r++, "X", controller.regX, 16);
        addReg(regs, r++, "Y", controller.regY, 16);
        addReg(regs, r++, "S", controller.regS, 16);
        addReg(regs, r++, "U", controller.regU, 16);
        addReg(regs, r++, "DP", controller.regDP, 8);
        addReg(regs, r++, "CC", controller.regCC, 8);

        Separator sep = new Separator();

        GridPane flags = new GridPane();
        flags.setHgap(8);
        flags.setVgap(6);

        int fr = 0;
        flags.add(new Label("Flags:"), 0, fr++, 2, 1);

        flags.add(flagChip("E", controller.fE), 0, fr);
        flags.add(flagChip("F", controller.fF), 1, fr++);
        flags.add(flagChip("H", controller.fH), 0, fr);
        flags.add(flagChip("I", controller.fI), 1, fr++);
        flags.add(flagChip("N", controller.fN), 0, fr);
        flags.add(flagChip("Z", controller.fZ), 1, fr++);
        flags.add(flagChip("V", controller.fV), 0, fr);
        flags.add(flagChip("C", controller.fC), 1, fr++);

        right.getChildren().addAll(
                title, pc, cycles, new Separator(),
                regs, sep, flags, new Separator(),
                new Label("Last instruction:"), last
        );

        right.setPadding(new Insets(8));
        right.setSpacing(10);
        right.setStyle("-fx-background-color: #0f172a10; -fx-background-radius: 10;");
    }

    private void addReg(GridPane grid, int row, String name, javafx.beans.property.IntegerProperty value, int bits) {
        Label k = new Label(name + ":");
        Label v = new Label();
        v.setStyle("-fx-font-family: 'Consolas';");

        v.textProperty().bind(Bindings.createStringBinding(
                () -> (bits == 8 ? hex8(value.get()) : hex16(value.get())),
                value
        ));

        grid.add(k, 0, row);
        grid.add(v, 1, row);
    }

    private HBox flagChip(String name, javafx.beans.property.BooleanProperty on) {
        Label l = new Label(name);
        l.setMinWidth(18);
        l.setAlignment(Pos.CENTER);

        Region dot = new Region();
        dot.setMinSize(10, 10);
        dot.setPrefSize(10, 10);
        dot.setMaxSize(10, 10);

        dot.styleProperty().bind(Bindings.createStringBinding(() -> {
            if (on.get()) return "-fx-background-color: #22c55e; -fx-background-radius: 5;";
            return "-fx-background-color: #94a3b8; -fx-background-radius: 5;";
        }, on));

        HBox box = new HBox(6, dot, l);
        box.setAlignment(Pos.CENTER_LEFT);
        return box;
    }


    // Console binding

    private void setupConsole() {
        console.setItems(controller.consoleLines());
        console.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 12px;");
    }


    // UI Pump

    public void startUiPump() {
        setupRegistersPanel();

        timer = new AnimationTimer() {
            private long last = 0;

            @Override
            public void handle(long now) {
                if (last != 0 && (now - last) < 16_000_000) return; // ~60fps
                last = now;

                controller.pumpUi();

                MemoryPane ramPane = (MemoryPane) root.getProperties().get("ramPane");
                MemoryPane romPane = (MemoryPane) root.getProperties().get("romPane");
                if (ramPane != null) ramPane.refresh();
                if (romPane != null) romPane.refresh();

                Integer line = controller.lineForPc(controller.pcProperty().get());
                if (line != null && !line.equals(highlightedLine)) {
                    highlightLine(line);
                }
            }
        };
        timer.start();
    }


    // Helpers

    private static Integer parseHexOrNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        t = t.replace("_", "");
        if (t.startsWith("$")) t = t.substring(1);
        if (t.startsWith("0x") || t.startsWith("0X")) t = t.substring(2);
        return Integer.parseInt(t, 16) & 0xFFFF;
    }

    private static int parseIntSafe(String s, int def) {
        try { return Integer.parseInt(s.trim()); }
        catch (Exception e) { return def; }
    }

    private static String hex8(int v)  { return String.format("$%02X", v & 0xFF); }
    private static String hex16(int v) { return String.format("$%04X", v & 0xFFFF); }

    private static String defaultProgram() {
        return """
                ; --- Minimal program template ---
                ORG $E000
                START:
                    LDA #$42
                    STA $0100
                    BRA START
                END
                """;
    }
}*/