package com.simulator.moto6809.UI;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.util.converter.DefaultStringConverter;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntBinaryOperator;
import java.util.function.IntUnaryOperator;

public final class MemoryPane extends BorderPane {

    private final IntUnaryOperator peek;
    private final IntBinaryOperator pokeOrNull; // null => read-only (ROM)

    private final int rangeStart;
    private final int rangeEnd;

    private int base;
    private int pageSize;

    private final ObservableList<Row> rows = FXCollections.observableArrayList();
    private final TableView<Row> table = new TableView<>(rows);

    private final TextField baseField = new TextField();
    private final TextField pageField = new TextField();

    public MemoryPane(String title,
                      IntUnaryOperator peek,
                      IntBinaryOperator pokeOrNull,
                      int rangeStart,
                      int rangeEnd,
                      int pageSize) {

        this.peek = peek;
        this.pokeOrNull = pokeOrNull;

        this.rangeStart = rangeStart & 0xFFFF;
        this.rangeEnd = rangeEnd & 0xFFFF;
        this.pageSize = Math.max(16, pageSize);

        this.base = this.rangeStart;

        setPadding(new Insets(8));

        Label lbl = new Label(title + String.format("  (Range $%04X-$%04X)", this.rangeStart, this.rangeEnd));

        Button btnPrev = new Button("Prev");
        Button btnNext = new Button("Next");
        Button btnRefresh = new Button("Refresh");

        baseField.setPrefColumnCount(6);
        pageField.setPrefColumnCount(4);

        baseField.setText(String.format("$%04X", base));
        pageField.setText(String.valueOf(this.pageSize));

        btnPrev.setOnAction(e -> { setBase(base - this.pageSize); refresh(); });
        btnNext.setOnAction(e -> { setBase(base + this.pageSize); refresh(); });
        btnRefresh.setOnAction(e -> refresh());

        baseField.setOnAction(e -> {
            Integer v = parseHexOrNull(baseField.getText());
            if (v != null) setBase(v);
            refresh();
        });

        pageField.setOnAction(e -> {
            try {
                int s = Integer.parseInt(pageField.getText().trim());
                if (s < 16) s = 16;
                this.pageSize = s;
            } catch (Exception ignored) {}
            refresh();
        });

        HBox top = new HBox(10,
                lbl,
                new Label("Base:"), baseField,
                new Label("Size:"), pageField,
                btnPrev, btnNext, btnRefresh
        );
        top.setPadding(new Insets(0, 0, 8, 0));
        setTop(top);

        setupTable(title);
        setCenter(table);

        refresh();
    }

    private void setupTable(String title) {
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Row, String> cAddr = new TableColumn<>("Addr");
        cAddr.setMaxWidth(120);
        cAddr.setCellValueFactory(v -> v.getValue().addrProperty());

        TableColumn<Row, String> cHex = new TableColumn<>("Hex (16 bytes)");
        cHex.setCellValueFactory(v -> v.getValue().hexProperty());

        // Editable only when pokeOrNull != null (RAM)
        boolean editable = (pokeOrNull != null);
        table.setEditable(editable);
        cHex.setEditable(editable);

        if (editable) {
            cHex.setCellFactory(col -> {
                TextFieldTableCell<Row, String> cell =
                        new TextFieldTableCell<>(new DefaultStringConverter());
                cell.setTooltip(new Tooltip("Edit bytes like: 00 11 22 ... (up to 16) ثم Enter"));
                return cell;
            });

            cHex.setOnEditCommit(ev -> {
                Row row = ev.getRowValue();
                String text = ev.getNewValue();
                if (row == null) return;

                List<Integer> parsed = parseHexBytes(text);
                if (parsed.isEmpty()) {
                    // revert display
                    refresh();
                    return;
                }

                int addr = row.address();
                for (int i = 0; i < parsed.size(); i++) {
                    int a = (addr + i) & 0xFFFF;
                    if (a < rangeStart || a > rangeEnd) break;
                    pokeOrNull.applyAsInt(a, parsed.get(i));
                }
                refresh();
            });
        }

        table.getColumns().setAll(cAddr, cHex);
    }

    private void setBase(int addr) {
        int v = addr & 0xFFFF;
        if (v < rangeStart) v = rangeStart;
        if (v > rangeEnd) v = rangeEnd;
        base = v;
        baseField.setText(String.format("$%04X", base));
    }

    public void refresh() {
        rows.clear();

        int remaining = pageSize;
        int addr = base;

        while (remaining > 0 && addr <= rangeEnd) {
            int rowAddr = addr;
            StringBuilder sb = new StringBuilder();

            int n = Math.min(16, remaining);
            for (int i = 0; i < n; i++) {
                int a = (addr + i) & 0xFFFF;
                if (a > rangeEnd) break;
                int b = peek.applyAsInt(a) & 0xFF;
                if (i > 0) sb.append(' ');
                sb.append(String.format("%02X", b));
            }

            rows.add(new Row(rowAddr, String.format("$%04X", rowAddr), sb.toString()));

            addr += n;
            remaining -= n;
        }
    }

    private static Integer parseHexOrNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        t = t.replace("_", "");
        if (t.startsWith("$")) t = t.substring(1);
        if (t.startsWith("0x") || t.startsWith("0X")) t = t.substring(2);
        return Integer.parseInt(t, 16) & 0xFFFF;
    }

    private static List<Integer> parseHexBytes(String text) {
        if (text == null) return List.of();
        String t = text.trim();
        if (t.isEmpty()) return List.of();

        // allow "00 11 22" or "001122" (we'll split smart)
        String[] parts = t.contains(" ") ? t.split("\\s+") : new String[]{t};

        List<Integer> out = new ArrayList<>();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            p = p.replace("$", "").replace("0x", "").replace("0X", "");

            if (p.length() == 2) {
                out.add(Integer.parseInt(p, 16) & 0xFF);
            } else if (p.length() % 2 == 0) {
                for (int i = 0; i < p.length(); i += 2) {
                    out.add(Integer.parseInt(p.substring(i, i + 2), 16) & 0xFF);
                    if (out.size() >= 16) break;
                }
            } else {
                // invalid -> ignore
                return List.of();
            }
            if (out.size() >= 16) break;
        }
        return out;
    }
}

/*33package com.simulator.moto6809.UI;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.function.IntUnaryOperator;

public final class MemoryPane extends BorderPane {

    private final IntUnaryOperator peek;
    private final int rangeStart;
    private final int rangeEnd;

    private int base;
    private int pageSize;

    private final ObservableList<Row> rows = FXCollections.observableArrayList();
    private final TableView<Row> table = new TableView<>(rows);

    private final TextField baseField = new TextField();
    private final TextField pageField = new TextField();

    public MemoryPane(String title,
                      IntUnaryOperator peek,
                      int rangeStart,
                      int rangeEnd,
                      int pageSize) {

        this.peek = peek;
        this.rangeStart = rangeStart & 0xFFFF;
        this.rangeEnd = rangeEnd & 0xFFFF;
        this.pageSize = Math.max(16, pageSize);

        this.base = this.rangeStart;

        setPadding(new Insets(8));

        Label lbl = new Label(title + String.format("  (Range $%04X-$%04X)", this.rangeStart, this.rangeEnd));

        Button btnPrev = new Button("Prev");
        Button btnNext = new Button("Next");
        Button btnRefresh = new Button("Refresh");

        baseField.setPrefColumnCount(6);
        pageField.setPrefColumnCount(4);

        baseField.setText(String.format("$%04X", base));
        pageField.setText(String.valueOf(this.pageSize));

        btnPrev.setOnAction(e -> { setBase(base - this.pageSize); refresh(); });
        btnNext.setOnAction(e -> { setBase(base + this.pageSize); refresh(); });

        btnRefresh.setOnAction(e -> refresh());

        baseField.setOnAction(e -> {
            Integer v = parseHexOrNull(baseField.getText());
            if (v != null) setBase(v);
            refresh();
        });

        pageField.setOnAction(e -> {
            try {
                int s = Integer.parseInt(pageField.getText().trim());
                if (s < 16) s = 16;
                this.pageSize = s;
            } catch (Exception ignored) {}
            refresh();
        });

        HBox top = new HBox(10,
                lbl,
                new Label("Base:"), baseField,
                new Label("Size:"), pageField,
                btnPrev, btnNext, btnRefresh
        );
        top.setPadding(new Insets(0, 0, 8, 0));

        setTop(top);

        setupTable();
        setCenter(table);

        refresh();
    }

    private void setupTable() {
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Row, String> cAddr = new TableColumn<>("Addr");
        cAddr.setCellValueFactory(v -> v.getValue().addrProperty());

        TableColumn<Row, String> cHex = new TableColumn<>("Hex (16 bytes)");
        cHex.setCellValueFactory(v -> v.getValue().hexProperty());

        table.getColumns().setAll(cAddr, cHex);
    }

    private void setBase(int addr) {
        int v = addr & 0xFFFF;
        if (v < rangeStart) v = rangeStart;
        if (v > rangeEnd) v = rangeEnd;
        base = v;
        baseField.setText(String.format("$%04X", base));
    }

    public void refresh() {
        rows.clear();

        int remaining = pageSize;
        int addr = base;

        while (remaining > 0 && addr <= rangeEnd) {
            int rowAddr = addr;
            StringBuilder sb = new StringBuilder();

            int n = Math.min(16, remaining);
            for (int i = 0; i < n; i++) {
                int a = (addr + i) & 0xFFFF;
                if (a > rangeEnd) break;
                int b = peek.applyAsInt(a) & 0xFF;
                if (i > 0) sb.append(' ');
                sb.append(String.format("%02X", b));
            }

            rows.add(new Row(String.format("$%04X", rowAddr), sb.toString()));

            addr += n;
            remaining -= n;
        }
    }

    private static Integer parseHexOrNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        t = t.replace("_", "");
        if (t.startsWith("$")) t = t.substring(1);
        if (t.startsWith("0x") || t.startsWith("0X")) t = t.substring(2);
        return Integer.parseInt(t, 16) & 0xFFFF;
    }
}*/


/*22package com.simulator.moto6809.UI;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.function.IntUnaryOperator;

public final class MemoryPane extends BorderPane {

    private final IntUnaryOperator peek;
    private final int start;
    private final int length;

    private final ObservableList<Row> rows = FXCollections.observableArrayList();
    private final TableView<Row> table = new TableView<>(rows);

    public MemoryPane(String title, IntUnaryOperator peek, int start, int length) {
        this.peek = peek;
        this.start = start & 0xFFFF;
        this.length = Math.max(0, length);

        setPadding(new Insets(8));

        Label lbl = new Label(title);
        Button btnRefresh = new Button("Refresh");
        btnRefresh.setOnAction(e -> refresh());

        HBox top = new HBox(10, lbl, btnRefresh);
        top.setPadding(new Insets(0, 0, 8, 0));
        setTop(top);

        setupTable();
        setCenter(table);

        refresh();
    }

    private void setupTable() {
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setPrefHeight(400);

        TableColumn<Row, String> cAddr = new TableColumn<>("Addr");
        cAddr.setCellValueFactory(v -> v.getValue().addrProperty());

        TableColumn<Row, String> cHex = new TableColumn<>("Hex (16 bytes)");
        cHex.setCellValueFactory(v -> v.getValue().hexProperty());

        table.getColumns().setAll(cAddr, cHex);
    }

    public void refresh() {
        rows.clear();

        int end = (start + length) & 0xFFFF;
        int addr = start;

        // show 16 bytes per row
        int count = length;
        while (count > 0) {
            int rowAddr = addr;
            StringBuilder sb = new StringBuilder();

            int n = Math.min(16, count);
            for (int i = 0; i < n; i++) {
                int b = peek.applyAsInt((addr + i) & 0xFFFF) & 0xFF;
                if (i > 0) sb.append(' ');
                sb.append(String.format("%02X", b));
            }

            rows.add(new Row(String.format("$%04X", rowAddr), sb.toString()));

            addr = (addr + n) & 0xFFFF;
            count -= n;
        }
    }
}*/
/*11package com.simulator.moto6809.UI;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.function.IntUnaryOperator;

public final class MemoryPane extends BorderPane {

    private final IntUnaryOperator reader;

    private final IntegerProperty startAddress = new SimpleIntegerProperty(0);
    private final IntegerProperty pageSize = new SimpleIntegerProperty(256);

    private final TableView<Row> table = new TableView<>();
    private final ObservableList<Row> rows = FXCollections.observableArrayList();

    private final TextField startField = new TextField("$0000");
    private final ComboBox<Integer> sizeBox = new ComboBox<>();

    public MemoryPane(String title, IntUnaryOperator reader, int initialStart, int initialSize) {
        this.reader = reader;

        setPadding(new Insets(8));

        Label t = new Label(title);

        sizeBox.getItems().addAll(128, 256, 512, 1024, 2048);
        sizeBox.setValue(initialSize);

        startAddress.set(initialStart & 0xFFFF);
        pageSize.set(initialSize);

        startField.setPrefColumnCount(8);
        startField.setText(hex16(startAddress.get()));

        Button prev = new Button("<<");
        Button next = new Button(">>");
        Button apply = new Button("Apply");
        Button refresh = new Button("Refresh");

        prev.setOnAction(e -> setStart(startAddress.get() - pageSize.get()));
        next.setOnAction(e -> setStart(startAddress.get() + pageSize.get()));
        apply.setOnAction(e -> {
            Integer a = parseHexOrNull(startField.getText());
            if (a != null) setStart(a);
            Integer s = sizeBox.getValue();
            if (s != null) setSize(s);
        });
        refresh.setOnAction(e -> table.refresh());

        sizeBox.valueProperty().addListener((obs, o, n) -> {
            if (n != null) setSize(n);
        });

        HBox top = new HBox(8,
                t,
                new Separator(),
                new Label("Start:"), startField,
                new Label("Size:"), sizeBox,
                prev, next, apply,
                new Separator(),
                refresh
        );
        top.setAlignment(Pos.CENTER_LEFT);
        top.setPadding(new Insets(0, 0, 8, 0));
        setTop(top);

        buildTable();
        setCenter(table);

        rebuildRows();
    }

    public void refresh() {
        table.refresh();
    }

    private void setStart(int addr) {
        startAddress.set(addr & 0xFFFF);
        startField.setText(hex16(startAddress.get()));
        rebuildRows();
    }

    private void setSize(int size) {
        pageSize.set(size);
        rebuildRows();
    }

    private void buildTable() {
        TableColumn<Row, Number> addrCol = new TableColumn<>("Address");
        addrCol.setPrefWidth(120);
        addrCol.setCellValueFactory(cd -> cd.getValue().addressProperty());
        addrCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? null : hex16(item.intValue()));
            }
        });

        TableColumn<Row, Number> valCol = new TableColumn<>("Value");
        valCol.setPrefWidth(90);
        // On met "address" comme valueFactory, puis on lit en live dans updateItem
        valCol.setCellValueFactory(cd -> cd.getValue().addressProperty());
        valCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    return;
                }
                int addr = item.intValue() & 0xFFFF;
                int v = reader.applyAsInt(addr) & 0xFF;
                setText(hex8(v));
            }
        });

        table.getColumns().setAll(addrCol, valCol);
        table.setItems(rows);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
    }

    private void rebuildRows() {
        rows.clear();
        int start = startAddress.get() & 0xFFFF;
        int n = pageSize.get();
        for (int i = 0; i < n; i++) {
            rows.add(new Row((start + i) & 0xFFFF));
        }
    }

    private static final class Row {
        private final ReadOnlyIntegerWrapper address = new ReadOnlyIntegerWrapper();
        Row(int address) { this.address.set(address & 0xFFFF); }
        public javafx.beans.property.ReadOnlyIntegerProperty addressProperty() { return address.getReadOnlyProperty(); }
    }

    private static Integer parseHexOrNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        t = t.replace("_", "");
        if (t.startsWith("$")) t = t.substring(1);
        if (t.startsWith("0x") || t.startsWith("0X")) t = t.substring(2);
        return Integer.parseInt(t, 16) & 0xFFFF;
    }

    private static String hex8(int v)  { return String.format("$%02X", v & 0xFF); }
    private static String hex16(int v) { return String.format("$%04X", v & 0xFFFF); }
}*/
