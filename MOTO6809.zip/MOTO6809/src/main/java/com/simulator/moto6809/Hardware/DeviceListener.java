package com.simulator.moto6809.Hardware;

public interface DeviceListener
{
    void onDeviceStateChanged(Device device);
}
