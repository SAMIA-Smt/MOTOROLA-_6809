package com.simulator.moto6809.UI;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.util.function.BiConsumer;
import java.util.function.IntUnaryOperator;

public final class MemoryGridPane extends BorderPane {

    private final IntUnaryOperator peek;
    private final BiConsumer<Integer, Integer> poke; // null => read-only
    private final boolean editable;

    private final int rangeStart;
    private final int rangeEnd;

    private int base;
    private int rowsCount = 16; // 16 rows => 256 bytes per page

    private final ObservableList<MemRow> rows = FXCollections.observableArrayList();
    private final TableView<MemRow> table = new TableView<>(rows);

    private final TextField baseField = new TextField();
    private final TextField rowsField = new TextField();

    public MemoryGridPane(String title,
                          IntUnaryOperator peek,
                          BiConsumer<Integer, Integer> pokeOrNull,
                          int rangeStart,
                          int rangeEnd) {

        this.peek = peek;
        this.poke = pokeOrNull;
        this.editable = (pokeOrNull != null);

        this.rangeStart = rangeStart & 0xFFFF;
        this.rangeEnd   = rangeEnd & 0xFFFF;

        this.base = this.rangeStart;

        setPadding(new Insets(8));

        Label lbl = new Label(title + String.format("  (Range $%04X-$%04X)", this.rangeStart, this.rangeEnd));

        Button btnPrev = new Button("Prev");
        Button btnNext = new Button("Next");
        Button btnRefresh = new Button("Refresh");

        baseField.setPrefColumnCount(6);
        rowsField.setPrefColumnCount(4);

        baseField.setText(String.format("$%04X", base));
        rowsField.setText(String.valueOf(rowsCount));

        btnPrev.setOnAction(e -> { setBase(base - rowsCount * 16); refresh(); });
        btnNext.setOnAction(e -> { setBase(base + rowsCount * 16); refresh(); });
        btnRefresh.setOnAction(e -> refresh());

        baseField.setOnAction(e -> { Integer v = parseHexOrNull(baseField.getText()); if (v != null) setBase(v); refresh(); });
        rowsField.setOnAction(e -> { setRowsCount(rowsField.getText()); refresh(); });

        HBox top = new HBox(10, lbl, new Label("Base:"), baseField, new Label("Rows:"), rowsField, btnPrev, btnNext, btnRefresh);
        top.setPadding(new Insets(0, 0, 8, 0));
        setTop(top);

        buildTable();
        setCenter(table);

        refresh();
    }

    private void setRowsCount(String txt) {
        try {
            int v = Integer.parseInt(txt.trim());
            if (v < 4) v = 4;
            if (v > 64) v = 64;
            rowsCount = v;
            rowsField.setText(String.valueOf(rowsCount));
        } catch (Exception ignored) {}
    }

    private void setBase(int addr) {
        int v = addr & 0xFFFF;
        v = v & 0xFFF0; // align to 16
        if (v < rangeStart) v = rangeStart & 0xFFF0;
        if (v > rangeEnd) v = (rangeEnd & 0xFFF0);
        base = v;
        baseField.setText(String.format("$%04X", base));
    }

    private void buildTable() {
        table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        table.setEditable(editable);
        table.setFixedCellSize(26);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<MemRow, String> cBase = new TableColumn<>("R/C");
        cBase.setPrefWidth(70);
        cBase.setCellValueFactory(v -> v.getValue().baseTextProperty());
        cBase.setStyle("-fx-font-family: 'Consolas';");

        table.getColumns().add(cBase);

        for (int i = 0; i < 16; i++) {
            final int colIndex = i;
            TableColumn<MemRow, String> c = new TableColumn<>(String.format("%02X", i));
            c.setPrefWidth(48);
            c.setCellValueFactory(v -> v.getValue().cellProperty(colIndex));
            c.setStyle("-fx-alignment: CENTER; -fx-font-family: 'Consolas';");

            if (editable) {
                c.setCellFactory(col -> new HexCell(colIndex));
                c.setOnEditCommit(ev -> {
                    MemRow row = ev.getRowValue();
                    if (row == null) return;

                    String t = (ev.getNewValue() == null) ? "" : ev.getNewValue().trim();
                    if (t.isEmpty()) { refresh(); return; }

                    if (!t.matches("[0-9A-Fa-f]{1,2}")) { refresh(); return; }

                    int value = Integer.parseInt(t, 16) & 0xFF;
                    int addr = (row.base + colIndex) & 0xFFFF;

                    if (addr < rangeStart || addr > rangeEnd) { refresh(); return; }

                    poke.accept(addr, value);
                    refresh();
                });
            } else {
                // read-only
                c.setCellFactory(col -> new TableCell<>() {
                    @Override protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        setText(empty ? "" : item);
                    }
                });
            }

            table.getColumns().add(c);
        }
    }

    public void refresh() {
        rows.clear();

        int addr = base;
        for (int r = 0; r < rowsCount; r++) {
            if (addr > rangeEnd) break;

            MemRow row = new MemRow(addr & 0xFFFF);
            for (int i = 0; i < 16; i++) {
                int a = (addr + i) & 0xFFFF;
                if (a > rangeEnd) {
                    row.setCell(i, "");
                } else {
                    int b = peek.applyAsInt(a) & 0xFF;
                    row.setCell(i, String.format("%02X", b));
                }
            }
            rows.add(row);
            addr = (addr + 16) & 0xFFFF;
        }
    }

    private static Integer parseHexOrNull(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        if (t.startsWith("$")) t = t.substring(1);
        if (t.startsWith("0x") || t.startsWith("0X")) t = t.substring(2);
        return Integer.parseInt(t, 16) & 0xFFFF;
    }

    // =========================
    // Row model
    // =========================
    public static final class MemRow {
        final int base;
        final StringProperty baseText = new SimpleStringProperty();
        final StringProperty[] cells = new StringProperty[16];

        MemRow(int base) {
            this.base = base & 0xFFFF;
            baseText.set(String.format("%04X", this.base));
            for (int i = 0; i < 16; i++) cells[i] = new SimpleStringProperty("00");
        }

        StringProperty baseTextProperty() { return baseText; }
        StringProperty cellProperty(int i) { return cells[i]; }
        void setCell(int i, String v) { cells[i].set(v); }
    }

    // =========================
    // Editable hex cell
    // =========================
    private static final class HexCell extends TextFieldTableCell<MemRow, String> {
        HexCell(int colIndex) { super(); }

        @Override public void startEdit() {
            super.startEdit();
            TextField tf = (TextField) getGraphic();
            if (tf != null) {
                tf.setText(getItem() == null ? "" : getItem());
                tf.selectAll();

                tf.setTextFormatter(new TextFormatter<String>(change -> {
                    String nt = change.getControlNewText();
                    if (nt.isEmpty()) return change;
                    if (nt.length() > 2) return null;
                    if (!nt.matches("[0-9A-Fa-f]*")) return null;
                    return change;
                }));
            }
        }
    }

    public boolean isEditing() {
        return table.getEditingCell() != null;
    }

}
