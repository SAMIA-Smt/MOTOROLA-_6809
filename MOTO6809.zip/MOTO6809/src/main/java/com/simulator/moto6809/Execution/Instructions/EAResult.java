package com.simulator.moto6809.Execution.Instructions;

public record EAResult(Integer ea, int extraCycles) {}
