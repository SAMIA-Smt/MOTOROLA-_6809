package com.simulator.moto6809.Problems;

public enum ProblemType
{
    WARNING,
    ERROR
}

