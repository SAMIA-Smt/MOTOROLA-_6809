package com.simulator.moto6809.Execution.CPU;

public enum InterruptType {
    RESET,
    NMI,
    IRQ,
    FIRQ,
    SWI,
    SWI2,
    SWI3
}
