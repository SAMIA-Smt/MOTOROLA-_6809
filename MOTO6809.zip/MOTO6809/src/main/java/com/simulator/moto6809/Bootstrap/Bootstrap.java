package com.simulator.moto6809.Bootstrap;

import com.simulator.moto6809.Assembler.Assembler;
import com.simulator.moto6809.Assembler.AssemblerProgram;
import com.simulator.moto6809.Assembler.OpcodeSelector;

import com.simulator.moto6809.Debugger.BreakpointManager;
import com.simulator.moto6809.Debugger.DebugController;

import com.simulator.moto6809.Decoder.InstructionSet;

import com.simulator.moto6809.Execution.CPU.CPU;

import com.simulator.moto6809.Errors.Response;
import com.simulator.moto6809.Logger.ILogger;
import com.simulator.moto6809.Logger.LogLevel;

import com.simulator.moto6809.Memory.Memory;
import com.simulator.moto6809.Memory.MemoryBus;

import com.simulator.moto6809.Registers.RegisterFunctions;

import com.simulator.moto6809.Resource.InstructionCsvLoader;
import com.simulator.moto6809.Resource.InstructionCsvRow;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

public final class Bootstrap {

    private final ILogger logger;

    private final Memory memory;
    private final MemoryBus bus;

    private final InstructionSet instructionSet;
    private final RegisterFunctions registers;

    private final BreakpointManager breakpointManager;
    private final DebugController debugController;

    private final CPU cpu;

    private final AssemblerProgram assemblerProgram;

    public Bootstrap(ILogger logger) {
        this.logger = (logger != null) ? logger : new StdoutLogger();

        this.memory = new Memory(this.logger);
        this.bus = new MemoryBus(this.memory);

        this.instructionSet = new InstructionSet(this.logger);
        this.registers = new RegisterFunctions(this.logger);

        this.breakpointManager = new BreakpointManager();
        this.debugController = new DebugController(this.breakpointManager);
        this.debugController.stop();

        this.cpu = new CPU(this.bus, this.registers, this.instructionSet, this.logger, this.debugController);

        this.assemblerProgram = buildAssemblerProgram(this.logger, this.instructionSet);
    }

    public Memory memory() { return memory; }
    public MemoryBus bus() { return bus; }
    public InstructionSet instructionSet() { return instructionSet; }
    public RegisterFunctions registers() { return registers; }
    public DebugController debug() { return debugController; }
    public CPU cpu() { return cpu; }
    public AssemblerProgram assemblerProgram() { return assemblerProgram; }

    public int loadAsmToRom(List<String> asmLines, Integer defaultOrigin, boolean writeResetVectorIfMissing) {
        int origin = (defaultOrigin != null) ? (defaultOrigin & 0xFFFF) : (memory.getROMstart() & 0xFFFF);
        bus.syncRomRangeFrom(memory);
        return assemblerProgram.assembleToRom(memory, asmLines, origin, writeResetVectorIfMissing);
    }

    public void resetCpu() {
        bus.syncRomRangeFrom(memory);
        cpu.reset();
    }

    public void run(int maxInstructions) {
        cpu.run(maxInstructions);
    }

    public int stepOnce() {
        return cpu.stepOnce();
    }

    public void addBreakpoint(int address) { breakpointManager.add(address & 0xFFFF); }
    public void removeBreakpoint(int address) { breakpointManager.remove(address & 0xFFFF); }
    public void clearBreakpoints() { breakpointManager.clear(); }

    public void clearRam() { bus.clearRamOnly(); }

    public void clearRom(boolean keepVectors) {
        memory.clearRom(keepVectors);
        bus.syncRomRangeFrom(memory);
    }


    /** Listing for UI mapping PC <-> line. */
    public List<AssemblerProgram.ListingRow> assembleListing(List<String> asmLines, int origin) {
        return assemblerProgram.assembleListing(asmLines, origin & 0xFFFF);
    }

    private AssemblerProgram buildAssemblerProgram(ILogger logger, InstructionSet instructionSet) {
        InstructionCsvLoader loader = new InstructionCsvLoader(logger);
        Map<String, InstructionCsvRow> opcodeTable = loader.loadOpcodeTable();

        OpcodeSelector selector = new OpcodeSelector(opcodeTable);
        Assembler assembler = new Assembler(selector, instructionSet);
        return new AssemblerProgram(assembler, instructionSet);
    }

    private static final class StdoutLogger implements ILogger {
        @Override public void log(String message, LogLevel level) {
            String msg = "[" + level + "] " + message;
            if (level == LogLevel.ERROR) System.err.println(msg);
            else System.out.println(msg);
        }
        @Override public void log(Response response, LogLevel level) { log(String.valueOf(response), level); }
        @Override public void clear() {}
        @Override public void setLogFilePath(Path logFilePath) {}
    }
    public int loadAsmFileToRom(Path asmFile, Integer defaultOrigin, boolean writeResetVectorIfMissing) throws IOException {
        if (asmFile == null) throw new IllegalArgumentException("asmFile is null");
        List<String> lines = Files.readAllLines(asmFile);
        return loadAsmToRom(lines, defaultOrigin, writeResetVectorIfMissing);
    }

    public int loadAsmFileToRom(Path asmFile) throws IOException {
        return loadAsmFileToRom(asmFile, null, true);
    }

}

/*11package com.simulator.moto6809.Bootstrap;
import com.simulator.moto6809.Assembler.Assembler;
import com.simulator.moto6809.Assembler.AssemblerProgram;
import com.simulator.moto6809.Assembler.OpcodeSelector;
import com.simulator.moto6809.Debugger.BreakpointManager;
import com.simulator.moto6809.Debugger.DebugController;
import com.simulator.moto6809.Decoder.InstructionSet;
import com.simulator.moto6809.Execution.CPU.CPU;
import com.simulator.moto6809.Errors.Response;
import com.simulator.moto6809.Logger.ILogger;
import com.simulator.moto6809.Logger.LogLevel;
import com.simulator.moto6809.Memory.Memory;
import com.simulator.moto6809.Memory.MemoryBus;
import com.simulator.moto6809.Registers.RegisterFunctions;
import com.simulator.moto6809.Resource.InstructionCsvLoader;
import com.simulator.moto6809.Resource.InstructionCsvRow;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Objects;
public final class Bootstrap {

    private final ILogger logger;

    private final Memory memory;
    private final MemoryBus bus;

    private final InstructionSet instructionSet;
    private final RegisterFunctions registers;

    private final BreakpointManager breakpointManager;
    private final DebugController debugController;

    private final CPU cpu;

    // Assembler toolchain
    private final AssemblerProgram assemblerProgram;

    public Bootstrap(ILogger logger) {
        this.logger = (logger != null) ? logger : new StdoutLogger();

        // 1) Memory (default layout inside Memory(logger): RAM 0000-DFFF, ROM E000-FFFF)
        this.memory = new Memory(this.logger);

        // 2) Bus shares the SAME byte[] + ROM protection
        this.bus = new MemoryBus(this.memory);
        this.bus.syncRomRangeFrom(this.memory);

        // 3) Instruction set (uses CSV/resources)
        this.instructionSet = new InstructionSet(this.logger);

        // 4) Registers
        this.registers = new RegisterFunctions(this.logger);

        // 5) Debugger
        this.breakpointManager = new BreakpointManager();
        this.debugController = new DebugController(this.breakpointManager);
        this.debugController.stop();

        // 6) CPU
        this.cpu = new CPU(this.bus, this.registers, this.instructionSet, this.logger, this.debugController);

        // 7) Assembler program
        this.assemblerProgram = buildAssemblerProgram(this.logger, this.instructionSet);
    }

    public static Bootstrap createDefault() {
        return new Bootstrap(null);
    }


    // Public getters

    public ILogger logger() { return logger; }

    public Memory memory() { return memory; }
    public MemoryBus bus() { return bus; }

    public InstructionSet instructionSet() { return instructionSet; }
    public RegisterFunctions registers() { return registers; }

    public DebugController debug() { return debugController; }
    public CPU cpu() { return cpu; }

    public AssemblerProgram assemblerProgram() { return assemblerProgram; }


    // Assemble + Load

    public int loadAsmToRom(List<String> asmLines, Integer defaultOrigin, boolean writeResetVectorIfMissing) {
        Objects.requireNonNull(asmLines, "asmLines");

        // Safety: keep ROM range in sync (in case memory layout changes)
        bus.syncRomRangeFrom(memory);

        int origin = (defaultOrigin != null)
                ? (defaultOrigin & 0xFFFF)
                : (memory.getROMstart() & 0xFFFF);

        return assemblerProgram.assembleToRom(memory, asmLines, origin, writeResetVectorIfMissing);
    }

    public int loadAsmToRom(List<String> asmLines) {
        return loadAsmToRom(asmLines, null, true);
    }

    public int loadAsmFileToRom(Path asmFile, Integer defaultOrigin, boolean writeResetVectorIfMissing) throws IOException {
        Objects.requireNonNull(asmFile, "asmFile");
        List<String> lines = Files.readAllLines(asmFile);
        return loadAsmToRom(lines, defaultOrigin, writeResetVectorIfMissing);
    }

    public int loadAsmFileToRom(Path asmFile) throws IOException {
        return loadAsmFileToRom(asmFile, null, true);
    }


    // CPU control

    public void resetCpu() {
        bus.syncRomRangeFrom(memory);
        cpu.reset();
    }

    public int stepOnce() {
        return cpu.stepOnce();
    }

    public void run(int maxInstructions) {
        cpu.run(maxInstructions);
    }



    public void addBreakpoint(int address) {
        breakpointManager.add(address & 0xFFFF);
    }

    public void removeBreakpoint(int address) {
        breakpointManager.remove(address & 0xFFFF);
    }

    public void clearBreakpoints() {
        breakpointManager.clear();
    }


    // Listing for UI (OPTIONNEL selon ton AssemblerProgram)


    public List<AssemblerProgram.ListingRow> assembleListing(List<String> asmLines, int origin) {
        return assemblerProgram.assembleListing(asmLines, origin & 0xFFFF);
    }



    // Build AssemblerProgram using CSV loader + OpcodeSelector

    private AssemblerProgram buildAssemblerProgram(ILogger logger, InstructionSet instructionSet) {
        InstructionCsvLoader loader = new InstructionCsvLoader(logger);

        // Opcode table (InstructionOpcode.csv)
        Map<String, InstructionCsvRow> opcodeTable = loader.loadOpcodeTable();

        OpcodeSelector selector = new OpcodeSelector(opcodeTable);
        Assembler assembler = new Assembler(selector, instructionSet);

        // In your PDF, AssemblerProgram supports (Assembler, InstructionSet)
        return new AssemblerProgram(assembler, instructionSet);
    }


    // Minimal logger fallback

    private static final class StdoutLogger implements ILogger {

        @Override
        public void log(String message, LogLevel level) {
            String msg = "[" + level + "] " + message;
            if (level == LogLevel.ERROR) System.err.println(msg);
            else System.out.println(msg);
        }

        @Override
        public void log(Response response, LogLevel level) {
            log(String.valueOf(response), level);
        }

        @Override
        public void clear() {
            // no-op
        }

        @Override
        public void setLogFilePath(Path logFilePath) {
            // no-op
        }
    }
}*/